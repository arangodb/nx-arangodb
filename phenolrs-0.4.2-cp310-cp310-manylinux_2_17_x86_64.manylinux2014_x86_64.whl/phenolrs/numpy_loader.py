from typing import Any, Tuple

import numpy as np
import numpy.typing as npt

from phenolrs import PhenolError, graph_to_numpy_format


class NumpyLoader:
    @staticmethod
    def load_graph_to_numpy(
        database: str,
        metagraph: dict[str, Any],
        hosts: list[str],
        user_jwt: str | None = None,
        username: str | None = None,
        password: str | None = None,
        tls_cert: Any | None = None,
        parallelism: int = 10,
        batch_size: int = 1000000,
    ) -> Tuple[
        dict[str, dict[str, npt.NDArray[np.float64]]],
        dict[Tuple[str, str, str], npt.NDArray[np.float64]],
        dict[str, dict[str, int]],
        dict[str, dict[int, str]],
        dict[str, dict[str, str]],
    ]:
        # TODO: replace with pydantic validation
        db_config_options: dict[str, Any] = {
            "endpoints": hosts,
        }

        if username:
            db_config_options["username"] = username
        if password:
            db_config_options["password"] = password
        if user_jwt:
            db_config_options["jwt_token"] = user_jwt
        if tls_cert:
            db_config_options["tls_cert"] = tls_cert

        if "vertexCollections" not in metagraph:
            raise PhenolError("vertexCollections not found in metagraph")

        # Address the possibility of having something like this:
        # "USER": {"x": {"features": None}}
        # Should be converted to:
        # "USER": {"x": "features"}
        entries: dict[str, Any]
        for v_col_name, entries in metagraph["vertexCollections"].items():
            for source_name, value in entries.items():
                if isinstance(value, dict):
                    if len(value) != 1:
                        m = f"Only one feature field should be specified per attribute. Found {value}"  # noqa: E501
                        raise PhenolError(m)

                    value_key = list(value.keys())[0]
                    if value[value_key] is not None:
                        m = f"Invalid value for feature {source_name}: {value_key}. Found {value[value_key]}"  # noqa: E501
                        raise PhenolError(m)

                    metagraph["vertexCollections"][v_col_name][source_name] = value_key

        vertex_collections = [
            {"name": v_col_name, "fields": list(entries.values())}
            for v_col_name, entries in metagraph["vertexCollections"].items()
        ]
        vertex_cols_source_to_output = {
            v_col_name: {
                source_name: output_name for output_name, source_name in entries.items()
            }
            for v_col_name, entries in metagraph["vertexCollections"].items()
        }

        edge_collections = []
        if "edgeCollections" in metagraph:
            edge_collections = [
                {"name": e_col_name, "fields": list(entries.values())}
                for e_col_name, entries in metagraph["edgeCollections"].items()
            ]

        load_config = {
            "parallelism": parallelism,
            "batch_size": batch_size,
            "load_vertices": True,
            "load_edges": len(edge_collections) > 0,
            "load_all_attributes_via_aql": False,
        }

        features_by_col, coo_map, col_to_adb_key_to_ind, col_to_ind_to_adb_key = (
            graph_to_numpy_format(
                {
                    "database": database,
                    "vertex_collections": vertex_collections,
                    "edge_collections": edge_collections,
                    "configuration": {
                        "database_config": db_config_options,
                        "load_config": load_config,
                    },
                }
            )
        )

        return (
            features_by_col,
            coo_map,
            col_to_adb_key_to_ind,
            col_to_ind_to_adb_key,
            vertex_cols_source_to_output,
        )
